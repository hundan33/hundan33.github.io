# Quick Start

1. Search the template file for the situation.
2. Copy the English message.
3. Replace blanks like `___`.
4. Check that the message matches your shop policy.
5. Send it to the customer.

## Best Uses

- Pre-sale questions.
- Order confirmation.
- Shipping delays.
- Damaged or missing items.
- Return/refund requests.
- Review follow-up.

## Important

This kit is not legal advice and does not override marketplace rules. Always follow the policy of the platform where you sell.
