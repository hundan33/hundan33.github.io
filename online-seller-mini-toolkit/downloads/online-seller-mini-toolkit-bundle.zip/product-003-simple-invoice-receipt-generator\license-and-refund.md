# License And Refund Draft

## License

You may use this tool to create invoice, receipt, and payment request drafts for your own work or your clients' work.

You may not resell, redistribute, or repackage the tool itself as a competing digital product.

## Refund Draft

This is a digital download. Because files can be accessed immediately after purchase, refunds are generally not available after download.

If the file is corrupted, inaccessible, or accidentally purchased twice, contact the seller for help.

Before publishing, adapt this policy to the rules of your selling platform.

## Disclaimer

This product is not accounting, tax, or legal advice. Buyers are responsible for checking local requirements.
