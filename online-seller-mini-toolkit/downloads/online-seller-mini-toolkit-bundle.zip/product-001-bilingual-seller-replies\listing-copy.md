# Listing Copy

## Product Title

Bilingual Seller Reply Kit: English Customer Service Templates With Chinese Notes

## Short Description

Answer buyer messages faster with copy-paste English customer service templates and Chinese usage notes for online sellers.

## Full Description

Running an online shop is stressful when every buyer message needs a careful English reply.

This digital download gives you ready-to-edit English customer service templates with Chinese notes explaining when to use each one.

Use it for:

- Product questions.
- Order confirmations.
- Shipping and tracking updates.
- Damaged/wrong/missing item complaints.
- Return and refund conversations.
- Review follow-ups.
- Short everyday replies.

What is included:

- 35+ customer reply templates.
- English copy-paste messages.
- Chinese usage notes.
- Offline browser reply generator.
- Quick-start instructions.
- Editing rules to avoid overpromising.

Good for:

- Etsy sellers.
- eBay sellers.
- Shopify sellers.
- Marketplace sellers.
- Cross-border sellers.
- Chinese speakers selling to English-speaking customers.

Important:

This is a digital template product. It does not guarantee sales, reviews, refunds, dispute outcomes, or marketplace approval. Always follow your platform and shop policies.

## Suggested Price

Launch price with the included browser generator: $19

Text-only discount option: $9

## Tags / Keywords

bilingual seller templates, customer service templates, ecommerce templates, Etsy seller, eBay seller, Shopify seller, cross border ecommerce, English reply templates, Chinese seller, digital download, customer support scripts, refund template, shipping delay template

## Cover Text Ideas

Option 1:

Bilingual Seller Reply Kit
English customer messages + Chinese notes

Option 2:

Reply Faster
35+ templates for online sellers

Option 3:

For Cross-Border Sellers
English support templates with Chinese guidance

## Promo Posts

Short post:

> I made a bilingual customer-service reply kit for online sellers who need English buyer replies with Chinese notes. Useful for product questions, shipping delays, returns, refunds, and review follow-ups. Digital download: [link]

Problem/solution post:

> If you sell online and spend too long writing English replies to buyers, this template kit can save time. It includes copy-paste English replies plus Chinese notes for when to use each one. [link]

Chinese post:

> 我做了一个跨境卖家英文客服回复模板包，里面有英文可复制话术和中文使用说明，适合处理售前问题、物流延迟、损坏/少件、退货退款、评价跟进等。数字下载：[link]

## First $100 Math

At $9:

- Need about 12 sales before platform/payment-fee differences.

At $19:

- Need about 6 sales before platform/payment-fee differences.

The included browser reply generator helps justify the $19 bundle price.
