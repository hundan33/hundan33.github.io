# Bilingual Seller Reply Kit

Upload-ready digital product for marketplace sellers who need quick English customer replies with Chinese notes.

Suggested listing price:

- Text-only launch price: $9
- Bundle price with the HTML generator: $19

Included files:

- `seller-reply-templates.md` - the product customers download.
- `seller-message-generator.html` - a tiny offline browser tool for generating replies.
- `quick-start.md` - simple usage instructions for buyers.
- `listing-copy.md` - title, description, pricing, keywords, and promo posts.
- `refund-policy.md` - plain-language policy you can adapt for your listing.

Buyer promise:

This product helps sellers answer common buyer questions faster. It does not guarantee sales, ratings, platform approval, or dispute outcomes.

Best upload platforms:

- Payhip or Ko-fi for low-friction testing.
- Gumroad for simple direct-link checkout.
- Etsy only if you want marketplace SEO work.
