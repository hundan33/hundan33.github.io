# One-Evening Digital Product Launch Checklist

## Pick The Small Outcome

- Choose one buyer.
- Choose one painful task.
- Choose one result the buyer can get today.
- Keep the product narrow enough to explain in one sentence.

Formula:

`This helps [buyer] do [task] without [common frustration].`

Examples:

- This helps online sellers answer buyer messages without rewriting the same replies.
- This helps job seekers draft follow-up emails without sounding stiff.
- This helps creators publish a tiny digital product without building a full course.

## Build The Download

- Create one main file: template pack, guide, CSV, or HTML tool.
- Add a `README.md` with usage steps.
- Add one example output.
- Add a short license/use note.
- Zip the folder.

## Create The Listing

- Title: specific buyer + specific outcome.
- Subtitle: one line on what is included.
- Description: problem, contents, who it is for, how to use it.
- Add 6-10 tags.
- Add a simple refund/support note.

## Price

Start simple:

- $5 for a short template pack.
- $9 for a polished mini kit.
- $19 for a tool plus templates.
- $29-$39 for a multi-tool bundle.

## Publish

- Upload the zip.
- Paste the listing.
- Add a cover image if available.
- Add one free preview file or screenshot.
- Test the checkout/download flow if the platform allows it.

## Share

Post one useful snippet per day:

- A before/after example.
- A checklist item.
- A common mistake.
- A tiny template sample.
- A link to the free sample or paid product.

## Track

Record every confirmed sale in:

`revenue-tracker/sales.csv`

The $100 goal is only complete when confirmed net revenue reaches $100.
