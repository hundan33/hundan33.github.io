# Invoice And Receipt Formulas

This product creates simple draft documents. Buyers should adapt output to their local rules and business requirements.

## Basic Invoice Formula

1. Seller name.
2. Client name.
3. Invoice number.
4. Date and due date.
5. Line items.
6. Subtotal, discount, tax, total.
7. Payment method.
8. Terms.

## Line Item Format

Use one line per item:

`Description | quantity | unit price`

Example:

`Logo design | 1 | 75`

`Template bundle | 2 | 19`

## Basic Receipt Formula

1. Seller name.
2. Buyer/client name.
3. Receipt number or payment reference.
4. Date.
5. What was paid for.
6. Amount received.
7. Payment method.

## Friendly Payment Request

> Hi [Client], invoice [Number] is ready for [Amount]. Payment can be sent by [Method]. Thank you.

## Important Limits

- This is not accounting advice.
- This is not tax advice.
- This is not legal advice.
- Some countries/regions require specific invoice fields.
- Buyers should check local requirements before using it for official records.
