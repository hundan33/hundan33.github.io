# Quick Start

1. Open `simple-invoice-receipt-generator.html` in your browser.
2. Fill in seller, client, date, due date, and payment method.
3. Add line items using this format: `description | quantity | unit price`.
4. Check tax, discount, subtotal, and total.
5. Copy the document and payment message.

## Best Uses

- Simple freelance invoices.
- Digital product receipts.
- Small seller payment requests.
- Draft records before entering data into an official system.

## Important

This is a simple drafting tool. It is not accounting, tax, or legal advice. Check your local invoice rules before using it for official business records.
