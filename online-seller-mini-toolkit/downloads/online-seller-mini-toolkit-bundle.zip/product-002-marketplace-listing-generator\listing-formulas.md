# Listing Copy Formulas

Use these formulas when the generator output needs a human pass.

## Fast Title Formula

`Product type + main buyer + main result`

Example:

> Digital Download: Customer Reply Templates for Online Sellers

## Benefit-First Description

Formula:

1. Who it is for.
2. What problem it solves.
3. What is included.
4. What it does not guarantee.

Example:

> This kit is for online sellers who need faster buyer replies. It gives you ready-to-edit messages for common customer situations so you do not start from a blank page. It includes English templates, usage notes, and a simple offline tool. It does not guarantee sales, reviews, or platform outcomes.

## Tag Formula

Use a mix of:

- Product type: template, generator, spreadsheet, guide.
- Buyer: seller, freelancer, creator, shop owner.
- Use case: customer service, listing copy, refunds, shipping.
- Format: digital download, HTML tool, PDF, Markdown.

## What To Avoid

- Guaranteed income claims.
- Fake urgency.
- Claims about platform ranking.
- Medical/legal/financial outcomes.
- Copying competitor listings.

## Quick Improvement Pass

Before publishing:

- Remove vague words like "best" unless you can prove them.
- Put the buyer and result in the first sentence.
- Make the included files clear.
- Add a plain limitation statement.
- Keep the refund/digital delivery language compatible with your platform.
