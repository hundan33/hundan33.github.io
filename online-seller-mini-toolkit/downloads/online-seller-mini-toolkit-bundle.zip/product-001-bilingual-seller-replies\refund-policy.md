# Refund Policy Draft

This is a digital download. Because digital files can be accessed immediately after purchase, refunds are generally not available after download.

If there is a file access problem, duplicate purchase, or corrupted file, please contact me and I will help fix it.

This template pack is educational and operational support material. It does not guarantee sales, positive reviews, platform decisions, refund outcomes, or dispute outcomes.

Before publishing, adapt this policy to the rules of your selling platform.
