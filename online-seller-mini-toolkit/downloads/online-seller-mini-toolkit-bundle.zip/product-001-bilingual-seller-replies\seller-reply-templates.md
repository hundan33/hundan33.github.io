# Bilingual Seller Reply Kit

Copy, edit, and send. Each template includes an English message and a Chinese note explaining when to use it.

## 1. Before Purchase

### Product Details

English:

> Hi, thanks for your interest. This item includes ___. The size/color/version is ___. If you want, I can also send an extra photo before you order.

中文说明：

用于客户询问商品包含什么、规格、颜色、版本时。

### Availability

English:

> Yes, this item is currently available. If you order today, I can prepare it within ___ business day(s).

中文说明：

用于确认有货和处理时间。

### Sizing

English:

> The measurements are ___. Please compare them with an item you already own, because fit can vary by brand and style.

中文说明：

用于服装、鞋、配件等尺码问题，降低退货风险。

### Compatibility

English:

> This is compatible with ___. I recommend checking your model number before ordering. If you send me the model, I can help confirm.

中文说明：

用于电子产品、配件、零件、软件模板等兼容性问题。

### Discount Request

English:

> Thanks for asking. The current price is already my best price for a single item. If you are ordering multiple items, I can check whether a bundle discount is possible.

中文说明：

用于礼貌拒绝砍价，同时保留多件购买空间。

## 2. After Purchase

### Order Confirmation

English:

> Thank you for your order. I have received it and will prepare it according to the listing details. I will update you when it is ready/shipped.

中文说明：

用于下单后第一条确认消息。

### Digital Delivery

English:

> Thank you for your purchase. Your digital file is ready through the download link on the order page. If you have trouble downloading it, please message me and I will help.

中文说明：

用于数字产品下载说明。

### Processing Delay

English:

> I am sorry for the delay. Your order is still being prepared and I expect it to be ready by ___. Thank you for your patience.

中文说明：

用于轻微延迟，给出明确时间。

### Address Confirmation

English:

> Before I ship, could you please confirm the delivery address is correct? I want to make sure the package goes to the right place.

中文说明：

用于地址看起来不完整或客户要求修改地址时。

### Upgrade Offer

English:

> I can offer an upgraded option for ___. The additional cost would be ___. If you want the upgrade, please confirm before I prepare the order.

中文说明：

用于加急、升级包装、升级版本等。

## 3. Shipping And Tracking

### Tracking Sent

English:

> Your order has shipped. The tracking number is ___. Please allow some time for the carrier to update the tracking page.

中文说明：

用于发货通知。

### Tracking Not Updating

English:

> Tracking can take 24-48 hours to update after the carrier receives the package. If it still does not update after that, I will help check the status.

中文说明：

用于客户担心物流没动。

### Delivered But Not Found

English:

> I am sorry you cannot find the package. Please check around the delivery area, mailbox, front desk, neighbors, or building office. If it still cannot be found, please contact the carrier and send me any update so I can help from my side.

中文说明：

用于显示已送达但客户没收到。保持同理心，不立即承诺退款。

### International Shipping Delay

English:

> International shipping can sometimes take longer because of customs or local carrier processing. I understand the wait is frustrating and will keep helping you check the tracking.

中文说明：

用于跨境物流延迟。

### Customs Note

English:

> Import taxes or customs fees are handled by the buyer according to local rules. I do not control these fees, but I can provide order information if the carrier requests it.

中文说明：

用于关税/进口费问题。请按平台规则调整。

## 4. Problems And Complaints

### General Apology

English:

> I am sorry this happened. Please send a photo/video of the issue and I will check the best solution for you.

中文说明：

用于任何问题的第一句，不先认定责任，先要证据。

### Damaged Item

English:

> I am sorry the item arrived damaged. Please send clear photos of the item, packaging, and shipping label. Once I review them, I will help with the next step.

中文说明：

用于损坏问题。

### Wrong Item

English:

> I am sorry for the mistake. Please send a photo of the item you received and the packing label. I will check the order and help fix it.

中文说明：

用于发错货。

### Missing Part

English:

> I am sorry a part is missing. Please send a photo of everything you received and tell me which part is missing. I will check what I can do next.

中文说明：

用于少件。

### Buyer Does Not Like Item

English:

> I am sorry it was not what you expected. Please tell me what feels different from the listing, and I will check the best option according to the shop policy.

中文说明：

用于“不喜欢/和想象不同”。引导到店铺政策。

## 5. Returns And Refunds

### Return Instructions

English:

> You can start a return according to the shop/platform policy. Please keep the item in its original condition and send the tracking information after shipping it back.

中文说明：

用于接受退货。

### Refund After Return

English:

> Once the returned item is received and checked, I will process the refund according to the shop/platform policy.

中文说明：

用于说明退款时间点。

### Digital Product Refund

English:

> Because this is a digital product, downloads are usually not refundable after access is delivered. If you have a problem with the file, please tell me what happened and I will help fix it.

中文说明：

用于数字产品退款。必须按平台政策调整。

### Partial Refund Offer

English:

> I can offer a partial refund of ___ as a solution. If you accept, I can process it according to the platform process.

中文说明：

用于小问题补偿。

### Polite Decline

English:

> I understand your request. Based on the listing details and shop policy, I am not able to offer ___ in this case. I can still help with ___.

中文说明：

用于拒绝不合理要求，同时给一个可行替代。

## 6. Reviews And Follow-Up

### Delivery Check-In

English:

> Hi, I saw the order was delivered. I hope everything arrived safely. If you have any issue, please message me and I will help.

中文说明：

用于物流显示送达后关怀。

### Review Request

English:

> Thank you again for your order. If everything looks good, a quick review would really help my small shop.

中文说明：

用于温和要评价。不要违反平台规则，不要用奖励换好评。

### Problem Before Review

English:

> If something is not right, please message me before leaving a review. I would like a chance to help fix the issue.

中文说明：

用于降低差评风险，但不要施压客户。

### Repeat Buyer

English:

> Thank you for coming back. I appreciate your repeat order and will prepare it carefully.

中文说明：

用于老客户。

### Bundle Follow-Up

English:

> If you need more than one item, message me before ordering and I can check whether a bundle option is available.

中文说明：

用于引导客单价提升。

## 7. Short Replies

### Yes

English:

> Yes, that works. I will proceed with ___.

中文说明：

简短确认。

### No

English:

> I am sorry, I cannot offer that option right now.

中文说明：

简短拒绝。

### Need More Info

English:

> Could you please send a little more detail so I can help correctly?

中文说明：

信息不足时。

### Thank You

English:

> Thank you for your patience and understanding.

中文说明：

用于安抚。

### Closing

English:

> I hope this helps. Please message me if you need anything else.

中文说明：

结束对话。

## Editing Rules

- Replace blanks before sending.
- Match your actual shop policy.
- Do not promise refunds, delivery dates, or outcomes you cannot control.
- Keep screenshots of difficult cases.
- Follow the marketplace rules first.
