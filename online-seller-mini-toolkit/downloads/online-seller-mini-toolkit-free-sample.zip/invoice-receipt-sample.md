# Invoice And Receipt Sample

Free sample from the Online Seller Mini Toolkit.

## Simple Invoice Template

```text
INVOICE
Number: INV-001
Date: 2026-07-02
Due date: 2026-07-02

From: Your Business
To: Client Name

Items:
- Digital product bundle: 1 x $39.00 = $39.00

Subtotal: $39.00
Discount: $0.00
Tax: $0.00
Total: $39.00

Payment: PayPal, Stripe, bank transfer, or agreed payment method
Terms: Payment due on receipt. Thank you.
```

## Simple Payment Message

> Hi Client Name, invoice INV-001 is ready for $39.00. Payment can be sent by PayPal, Stripe, bank transfer, or agreed payment method. Payment due on receipt. Thank you.

## Important

This is not accounting, tax, or legal advice. Check your local invoice requirements.

## Upgrade

The full toolkit includes an offline invoice and receipt generator with line items, tax, discount, totals, and payment message output: [paid link]
