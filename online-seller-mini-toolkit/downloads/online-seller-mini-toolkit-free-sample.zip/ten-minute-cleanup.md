# 10-Minute Seller Cleanup Checklist

Use this before publishing or updating a listing.

- [ ] The first sentence says who the product is for.
- [ ] The main benefit is clear.
- [ ] Included files are listed.
- [ ] Refund/digital delivery expectations are clear.
- [ ] No guaranteed sales, rankings, reviews, or income claims.
- [ ] Customer reply templates match your actual policy.
- [ ] Invoice/receipt text is checked against local requirements.
- [ ] Tags include product type, buyer, use case, and format.
- [ ] Cover image is readable at thumbnail size.
- [ ] The checkout link works.

## Upgrade

Get the full Online Seller Mini Toolkit for templates, offline generators, and listing assets: [paid link]
