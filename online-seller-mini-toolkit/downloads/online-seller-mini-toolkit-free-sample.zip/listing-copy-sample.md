# Listing Copy Sample

Free sample from the Online Seller Mini Toolkit.

## Fast Formula

`Product type + target buyer + main result`

Example:

> Digital Download: Customer Reply Templates for Online Sellers

## Description Formula

1. Who it is for.
2. What problem it solves.
3. What is included.
4. What it does not guarantee.

Example:

> This kit is for online sellers who need faster buyer replies. It gives you ready-to-edit messages for common customer situations so you do not start from a blank page. It includes English templates, usage notes, and a simple offline tool. It does not guarantee sales, reviews, or platform outcomes.

## Tags Formula

Use a mix of:

- Product type: template, generator, spreadsheet, guide.
- Buyer: seller, freelancer, creator, shop owner.
- Use case: customer service, listing copy, refunds, shipping.
- Format: digital download, HTML tool, PDF, Markdown.

## Upgrade

The full toolkit includes an offline listing copy generator that drafts titles, descriptions, tags, and buyer replies: [paid link]
