# Customer Reply Samples

Free sample from the Online Seller Mini Toolkit.

## 1. Product Details

English:

> Hi, thanks for your interest. This item includes ___. The size/color/version is ___. If you want, I can also send an extra photo before you order.

中文说明：

用于客户询问商品包含什么、规格、颜色、版本时。

## 2. Order Confirmation

English:

> Thank you for your order. I have received it and will prepare it according to the listing details. I will update you when it is ready or shipped.

中文说明：

用于下单后第一条确认消息。

## 3. Tracking Not Updating

English:

> Tracking can take 24-48 hours to update after the carrier receives the package. If it still does not update after that, I will help check the status.

中文说明：

用于客户担心物流没有更新。

## 4. Damaged Item

English:

> I am sorry the item arrived damaged. Please send clear photos of the item, packaging, and shipping label. Once I review them, I will help with the next step.

中文说明：

用于损坏问题，先收集证据。

## 5. Digital Download Help

English:

> Thank you for your purchase. Your digital file is ready through the download link on the order page. If you have trouble downloading it, please message me and I will help.

中文说明：

用于数字产品下载问题。

## 6. Review Request

English:

> Thank you again for your order. If everything looks good, a quick review would really help my small shop.

中文说明：

用于温和要评价。不要用奖励换好评。

## Upgrade

Get the full Online Seller Mini Toolkit for all templates and offline tools: [paid link]
